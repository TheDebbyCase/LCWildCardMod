## 0.0.2
- Updated README

## 0.0.1
- Released!