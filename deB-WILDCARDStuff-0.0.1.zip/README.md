# WILD/CARD Stuff

Repository for my very first mod, WILDCARD Stuff!

You can use the [Issues](https://github.com/TheDebbyCase/LCWildCardMod/issues) tab to submit any problems with the mod, or any suggestions you may have.
Suggestions can also be made directly to me in the mod-release thread on the [Lethal Company Modding Discord](https://discord.com/channels/1168655651455639582/1169056298856362105)!

## Thunderstore

Of course, see the Thunderstore page [here](https://thunderstore.io/c/lethal-company/p/deB/WILDCARD_Stuff)!
Or the GitHub page [here](https://github.com/TheDebbyCase/LCWildCardMod)!

## Content so far!

As of now, I have created:

- Scraps
	- Wormted Poster
	- NBickles
	- Moo Cow
	
And hope to add more soon! Make suggestions in the Discord!

## WILD/CARD

Last but not least, thank you to WILD/CARD and all members for making such great content and being a source of comfort and joy for me and many others. I can't lie and say I don't have my favourites (guess who) but I do hope to eventually have something to represent everyone!

Subscribe to [WILDCARD](https://www.youtube.com/@WILDCARDorg)!